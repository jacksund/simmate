The vasprun.xml is NOT from an NEB. It's just a dummy placeholder to indicate that this a vasp directory.
